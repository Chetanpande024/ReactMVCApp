﻿using ReactMVCWebApp.Models;
using System.Collections.Generic;
using System.Web.Mvc;

namespace ReactMVCWebApp.Controllers
{
    public class CustomerSupportController : Controller
    {
        public static List<CustomerData> memory = new List<CustomerData>();

        // GET: CustomerSupport
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public JsonResult SaveCustomerData(CustomerData data)
        {
            bool status = false;
            string message = "";
            if (ModelState.IsValid)
            {
                memory.Add(data);
                status = true;
                message = "Thank you for submitting your query";
            }
            else
            {
                message = "Failed! Please try again";
            }

            return new JsonResult { Data = new { status = status, message = message } };
        }
    }
}