﻿namespace ReactMVCWebApp.Models
{
    public class CustomerData
    {
        public string Email { get; set; }

        public string PhoneNo { get; set; }

        public string Number { get; set; }

        public string InquiryType { get; set; }

        public string IssueDescription { get; set; }
    }
}