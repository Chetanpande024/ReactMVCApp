﻿//React component for input component
var MyInput = React.createClass({
    //onchange event
    handleChange: function (e) {
        this.props.onChange(e.target.value);
        var isValidField = this.isValid(e.target);
    },
    //validation function
    isValid: function (input) {
        //check required field
        if (input.getAttribute('required') != null && input.value === "") {
            input.classList.add('error'); //add class error
            input.nextSibling.textContent = this.props.messageRequired; // show error message
            return false;
        }
        else {
            input.classList.remove('error');
            input.nextSibling.textContent = "";
        }
        //check data type // email validation
        if (input.getAttribute('type') == "email" && input.value != "") {
            if (!this.validateEmail(input.value)) {
                input.classList.add('error');
                input.nextSibling.textContent = this.props.messageEmail;
                return false;
            }
            else {
                input.classList.remove('error');
                input.nextSibling.textContent = "";
            }
        }
        return true;
    },
    //email validation function
    validateEmail: function (value) {
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(value);
    },
    componentDidMount: function () {
        if (this.props.onComponentMounted) {
            this.props.onComponentMounted(this); //register this input in the form
        }
    },
    //render
    render: function () {
        var inputField;
        if (this.props.type === 'checkbox') {
            inputField = <input type="checkbox" onChange={this.handleChange} checked={this.props.value} />
            return (
                <div className="form-group">
                    {inputField}
                    <span className="error"></span>
                </div>                 
            );
        }
        else {
            if (this.props.type == 'textarea') {
                inputField = <textarea value={this.props.value} ref={this.props.name} name={this.props.name}
                    className='form-control' required={this.props.isrequired} onChange={this.handleChange} />
            }
            else if (this.props.type == 'select') {
                const options = [
                    { value: '', label: '--Select--' },
                    { value: 'Type01', label: 'Type 01' },
                    { value: 'Type02', label: 'Type 02' },
                    { value: 'Type03', label: 'Type 03' },
                    { value: 'Type04', label: 'Type 04' },
                ];

                inputField = <select value={this.props.value} ref={this.props.name} name={this.props.name}
                    className='form-control' required={this.props.isrequired} onChange={this.handleChange}>
                    {options.map((option) => (
                        <option value={option.value}>{option.label}</option>
                    ))}
                </select>
            }
            else {
                inputField = <input type={this.props.type} value={this.props.value} ref={this.props.name} name={this.props.name}
                    className='form-control' required={this.props.isrequired} onChange={this.handleChange} />
            }
            return (
                <div className="form-group">
                    <label htmlFor={this.props.htmlFor}>{this.props.label}:</label>
                    {inputField}
                    <span className="error"></span>
                </div>
            );
        }
    }
});
//React component for generate form

var ContactForm = React.createClass({
    //get initial state
    getInitialState: function () {
        return {
            PhoneNo: '',
            Email: '',
            Number: '',
            IssueDescription: '',
            Fields: [],
            checked: false,
            ServerMessage: ''
        }
    },
    // submit function
    handleSubmit: function (e) {
        e.preventDefault();
        //Validate entire form here
        var validForm = true;
        this.state.Fields.forEach(function (field) {
            if (typeof field.isValid === "function") {
                var validField = field.isValid(field.refs[field.props.name]);
                validForm = validForm && validField;
            }
        });
        //after validation complete post to server 
        if (validForm) {
            var d = {
                Email: this.state.Email,
                PhoneNo: this.state.PhoneNo,
                Number: this.state.Number,
                InquiryType: this.state.InquiryType,
                IssueDescription: this.state.IssueDescription
            }

            $.ajax({
                type: "POST",
                url: this.props.urlPost,
                data: d,
                success: function (data) {
                    //Will clear form here
                    this.setState({
                        PhoneNo: '',
                        Number: '',
                        Email: '',
                        checked: false,
                        InquiryType: '',
                        IssueDescription: '',
                        ServerMessage: data.message
                    });
                }.bind(this),
                error: function (e) {
                    console.log(e);
                    alert('Error! Please try again');
                }
            });
        }
    },
    onChangePhoneNo: function (value) {
        this.setState({
            PhoneNo: value
        });
    },
    onChangeNumber: function (value) {
        this.setState({
            Number: value
        });
    },
    onChangeEmail: function (value) {
        this.setState({
            Email: value
        });
    },
    onChangeIssueDescription: function (value) {
        this.setState({
            IssueDescription: value
        });
    },
    onChangeTnC: function () {
        this.setState({
             checked: !this.state.checked
        });
    },
    onChangeInquiryType: function (value) {
        this.setState({
            InquiryType: value
        });
    },
    //register input controls
    register: function (field) {
        var s = this.state.Fields;
        s.push(field);
        this.setState({
            Fields: s
        })
    },
    //render
    render: function () {
        //Render form 
        return (
            <form name="contactForm" noValidate onSubmit={this.handleSubmit}>
                <MyInput type={'email'} value={this.state.Email} label={'Customer e-mail'} name={'Email'} htmlFor={'Email'} isrequired={true}
                    onChange={this.onChangeEmail} onComponentMounted={this.register} messageRequired={'E-mail required'} messageEmail={'Invalid e-mail'} />
                <MyInput type={'text'} value={this.state.PhoneNo} label={'Customer phone'} name={'PhoneNo'} htmlFor={'PhoneNo'} isrequired={true}
                    onChange={this.onChangePhoneNo} onComponentMounted={this.register} messageRequired={'Customer phone required'} />
                <MyInput type={'text'} value={this.state.Number} label={'Customer number'} name={'Number'} htmlFor={'Number'} isrequired={false}
                    onChange={this.onChangeNumber} onComponentMounted={this.register} />
                <MyInput type={'select'} value={this.state.InquiryType} label={'Inquiry Type'} name={'Inquiry Type'} htmlFor={'InquiryType'} isrequired={true}
                    onChange={this.onChangeInquiryType} onComponentMounted={this.register} messageRequired={'Inquiry Type required'} />
                <MyInput type={'textarea'} value={this.state.IssueDescription} label={'Issue description'} name={'IssueDescription'} htmlFor={'IssueDescription'} isrequired={true}
                    onChange={this.onChangeIssueDescription} onComponentMounted={this.register} messageRequired={'Issue description required'} />
                <MyInput type={'checkbox'} value={this.state.checked} onChange={this.onChangeTnC} />
                <span className="tncMsg">Terms and Conditions</span>
                <button type="submit" className="btn btn-success" disabled={!this.state.checked}>Submit</button>
                <p className="servermessage">{this.state.ServerMessage}</p>
            </form>
        );
    }
});

//Render react component into the page
ReactDOM.render(<ContactForm urlPost="/CustomerSupport/SaveCustomerData" />, document.getElementById('customerFormArea'));